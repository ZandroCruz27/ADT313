import './App.css';
import loginform from './component/loginform/loginform';
import profile from './component/profile/profile';
import mathoperation from './component/mathoperation/mathoperation';

import React, { useState } from 'react';

function App() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [num1, setNum1] = useState('');
    const [num2, setNum2] = useState('');
    const [operation, setOperation] = useState('');
    const [result, setResult] = useState(null);
  
    // Mock login details
    const correctUsername = 'user123';
    const correctPassword = 'password123';
  
    const handleLogin = () => {
      if (username === correctUsername && password === correctPassword) {
        setIsLoggedIn(true);
      } else {
        alert('Invalid username or password!');
      }
    };
  
    const handleCalculation = () => {
      const number1 = parseFloat(num1);
      const number2 = parseFloat(num2);
  
      if (isNaN(number1) || isNaN(number2)) {
        alert('Please enter valid numbers');
        return;
      }
  
      let result;
      switch (operation) {
        case 'add':
          result = number1 + number2;
          break;
        case 'subtract':
          result = number1 - number2;
          break;
        case 'multiply':
          result = number1 * number2;
          break;
        case 'divide':
          if (number2 === 0) {
            alert("Cannot divide by zero");
            return;
          }
          result = number1 / number2;
          break;
        default:
          alert('Please select an operation');
          return;
      }
  
      setResult(result);
    };
  
    if (!isLoggedIn) {
      return (
        <div className="login-container">
          <h2>Login</h2>
          <div>
            <label>Username: </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div>
            <label>Password: </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button onClick={handleLogin}>Login</button>
        </div>
      );
    }
  
    return (
      <div className="calculator-container">
        <h2>Calculator</h2>
        <div>
          <label>Number 1: </label>
          <input
            type="number"
            value={num1}
            onChange={(e) => setNum1(e.target.value)}
          />
        </div>
        <div>
          <label>Number 2: </label>
          <input
            type="number"
            value={num2}
            onChange={(e) => setNum2(e.target.value)}
          />
        </div>
        <div>
          <label>Operation: </label>
          <select onChange={(e) => setOperation(e.target.value)}>
            <option value="">Select</option>
            <option value="add">Add</option>
            <option value="subtract">Subtract</option>
            <option value="multiply">Multiply</option>
            <option value="divide">Divide</option>
          </select>
        </div>
        <button onClick={handleCalculation}>Calculate</button>
  
        {result !== null && (
          <div>
            <h3>Result: {result}</h3>
          </div>
        )}
      </div>
    );
  }
  

export default App;
