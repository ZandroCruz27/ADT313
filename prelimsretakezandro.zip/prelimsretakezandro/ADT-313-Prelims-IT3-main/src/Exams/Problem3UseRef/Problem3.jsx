import { useRef, useState } from 'react';

function Problem3() {
  const inputCount = 10; // Number of input fields
  const inputRefs = useRef([]); // Create a reference array for inputs
  const [inputs, setInputs] = useState(Array(inputCount).fill('')); // Track the input values

  // Handle button click: focus on the first empty input field
  const handleButtonClick = () => {
    // Loop through the input values to find the first empty input
    for (let i = 0; i < inputCount; i++) {
      if (inputs[i] === '') {
        inputRefs.current[i].focus(); // Focus on the empty input
        break;
      }
    }
  };

  // Handle input change
  const handleInputChange = (index, event) => {
    const newInputs = [...inputs];
    newInputs[index] = event.target.value;
    setInputs(newInputs);
  };

  return (
    <>
      {/* Dynamically render input fields */}
      {[...Array(inputCount)].map((_, index) => (
        <div key={index} style={{ marginBottom: '10px' }}>
          Input {index + 1}: 
          <input
            ref={(el) => (inputRefs.current[index] = el)} // Assign the ref to each input
            type="text"
            value={inputs[index]}
            onChange={(event) => handleInputChange(index, event)}
          />
        </div>
      ))}

      {/* Button */}
      <button type="button" onClick={handleButtonClick}>
        Focus on the first empty input
      </button>
    </>
  );
}

export default Problem3;
