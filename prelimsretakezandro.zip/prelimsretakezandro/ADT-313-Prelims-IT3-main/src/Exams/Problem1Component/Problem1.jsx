import react from 'react';

function  StudentProperties({ studentName, Course, Section}) {
    return(
        <div>
            <h2>Student Details</h2>
            <p><strong>Name: </strong> {studentName}</p>
            <p><strong>Course: </strong> {Course}</p>
            <p><strong>Section: </strong> {Section}</p>
        </div>
    );
}

export default StudentProperties;