import { useCallback, useState } from 'react';
import data from './problem8mock_data.json';

export default function Problem8() {
  const [foods, setFoods] = useState(data);
  const [selected, setSelected] = useState(null);

  // Handle input changes for form fields
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSelected((prevSelected) => ({
      ...prevSelected,
      [name]: value,
    }));
  };

  // Edit Button - Populate selected food item into the form
  const handleEdit = useCallback((food) => {
    setSelected(food);
  }, []);

  // Delete Button - Remove a food item from the array
  const handleDelete = useCallback((foodName) => {
    setFoods((prevFoods) => prevFoods.filter((food) => food.food_name !== foodName));
  }, []);

  // Save Button - Add a new food item if it doesn't exist, otherwise update
  const handleSave = useCallback(() => {
    if (selected) {
      setFoods((prevFoods) => {
        const foodIndex = prevFoods.findIndex((food) => food.food_name === selected.food_name);
        if (foodIndex > -1) {
          // Update existing food item
          const updatedFoods = [...prevFoods];
          updatedFoods[foodIndex] = selected;
          return updatedFoods;
        }
        // Add new food item
        return [...prevFoods, selected];
      });
      setSelected(null); // Clear form after saving
    }
  }, [selected]);

  // Clear Button - Clear all form fields
  const handleClear = useCallback(() => {
    setSelected(null);
  }, []);

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type="text"
            name="food_name"
            value={selected?.food_name || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type="text"
            name="price"
            value={selected?.price || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type="text"
            name="expiration_date"
            value={selected?.expiration_date || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type="text"
            name="calories"
            value={selected?.calories || ''}
            onChange={handleInputChange}
          />
        </div>

        <button type="button" onClick={handleSave}>
          Save
        </button>
        <button type="button" onClick={handleClear}>
          Clear
        </button>
      </div>
      <div className="table-container">
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food) => (
              <tr key={food.food_name}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(food)}>
                    Edit
                  </button>
                  <button type="button" onClick={() => handleDelete(food.food_name)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
