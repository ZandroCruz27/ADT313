// Selected.jsx
import { useSelectedDataContext } from '../SelectedDataContext';

function Selected() {
  const { selectedData } = useSelectedDataContext();

  return selectedData ? (
    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
      <div>
        <p><strong>Title:</strong> {selectedData.title}</p>
        <p><strong>Genre:</strong> {selectedData.genre}</p>
        <p><strong>Release Date:</strong> {selectedData.release_date}</p>
        <p><strong>Director:</strong> {selectedData.director}</p>
        <p><strong>Actor 1:</strong> {selectedData.actor_1}</p>
        <p><strong>Actor 2:</strong> {selectedData.actor_2}</p>
        <p><strong>Rating:</strong> {selectedData.rating}</p>
        <p><strong>Box Office:</strong> {selectedData.box_office}</p>
        <p><strong>Duration (Minutes):</strong> {selectedData.duration_minutes}</p>
        <p><strong>Language:</strong> {selectedData.language}</p>
      </div>
    </div>
  ) : (
    <p>Select a movie to see details.</p>
  );
}

export default Selected;
