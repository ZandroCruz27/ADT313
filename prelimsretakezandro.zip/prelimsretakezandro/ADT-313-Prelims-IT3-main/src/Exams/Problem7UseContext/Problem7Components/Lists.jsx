// Lists.jsx
import { useSelectedDataContext } from '../SelectedDataContext';
import data from './problem7_mock_data.json';

function Lists() {
  const { selectedData, setSelectedData } = useSelectedDataContext();

  return data && data.length ? (
    <table style={{ width: '100%' }}>
      <thead>
        <tr>
          <th>Title</th>
          <th>Genre</th>
          <th>Release Date</th>
          <th>Director</th>
          <th>Actor 1</th>
          <th>Actor 2</th>
          <th>Rating</th>
          <th>Box Office</th>
          <th>Duration (Minutes)</th>
          <th>Language</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {data.map((row, index) => (
          <tr
            key={index}
            style={{
              cursor: 'pointer',
              backgroundColor: selectedData && selectedData.title === row.title ? '#eef' : 'white',
            }}
          >
            <td>{row.title}</td>
            <td>{row.genre}</td>
            <td>{row.release_date}</td>
            <td>{row.director}</td>
            <td>{row.actor_1}</td>
            <td>{row.actor_2}</td>
            <td>{row.rating}</td>
            <td>{row.box_office}</td>
            <td>{row.duration_minutes}</td>
            <td>{row.language}</td>
            <td>
              <button
                onClick={() => setSelectedData(row)}
                style={{ padding: '5px', backgroundColor: 'lightblue' }}
              >
                Select
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  ) : (
    <p>No data available.</p>
  );
}

export default Lists;
