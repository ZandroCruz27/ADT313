import { useCallback, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selected, setSelected] = useState(null);

  // Handle input changes for form fields
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSelected((prevSelected) => ({
      ...prevSelected,
      [name]: value,
    }));
  };

  // Edit Button - Select a car to populate values into the form
  const handleEdit = useCallback((car) => {
    setSelected(car);
  }, []);

  // Delete Button - Remove a car from the array
  const handleDelete = useCallback((vin) => {
    setCars((prevCars) => prevCars.filter((car) => car.vin !== vin));
  }, []);

  // Save Button - Add a new car if no VIN exists, else update the existing car
  const handleSave = useCallback(() => {
    if (selected) {
      setCars((prevCars) => {
        const carIndex = prevCars.findIndex((car) => car.vin === selected.vin);
        if (carIndex > -1) {
          // Update existing car
          const updatedCars = [...prevCars];
          updatedCars[carIndex] = selected;
          return updatedCars;
        }
        // Add new car
        return [...prevCars, selected];
      });
      setSelected(null); // Clear form after saving
    }
  }, [selected]);

  // Clear Button - Clear all form fields
  const handleClear = useCallback(() => {
    setSelected(null);
  }, []);

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN:{' '}
          <input
            type="text"
            name="vin"
            value={selected?.vin || ''}
            onChange={handleInputChange}
            readOnly={!selected || selected?.vin} // VIN is read-only when editing existing entry
          />
        </div>
        <div style={{ display: 'block' }}>
          Make:{' '}
          <input
            type="text"
            name="make"
            value={selected?.make || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Model:{' '}
          <input
            type="text"
            name="model"
            value={selected?.model || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Year:{' '}
          <input
            type="text"
            name="year"
            value={selected?.year || ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Color:{' '}
          <input
            type="text"
            name="color"
            value={selected?.color || ''}
            onChange={handleInputChange}
          />
        </div>
        <button type="button" onClick={handleSave}>
          Save
        </button>
        <button type="button" onClick={handleClear}>
          Clear
        </button>
      </div>
      <div className="table-container">
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => (
              <tr key={car.vin}>
                <td>{car.vin}</td>
                <td>{car.make}</td>
                <td>{car.model}</td>
                <td>{car.year}</td>
                <td>{car.color}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(car)}>
                    Edit
                  </button>
                  <button type="button" onClick={() => handleDelete(car.vin)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
