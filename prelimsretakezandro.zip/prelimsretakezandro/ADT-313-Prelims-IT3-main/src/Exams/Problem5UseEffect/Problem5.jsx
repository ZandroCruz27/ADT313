import { useEffect, useState, useRef } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const idleTimerRef = useRef(null);

  // Dismiss the loading screen after 3 seconds
  useEffect(() => {
    const loadingTimer = setTimeout(() => setIsLoading(false), 3000);
    return () => clearTimeout(loadingTimer);
  }, []);

  // Handle typing detection
  const handleTyping = () => {
    setIsTyping(true);
    // Reset the idle timer
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    
    // Set a timer to switch to idle if no typing occurs for 5 seconds
    idleTimerRef.current = setTimeout(() => setIsTyping(false), 5000);
  };

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div style={{ display: 'block' }}>
          Input: <input type="text" onInput={handleTyping} />
          <p>{isTyping ? 'User is typing...' : 'User is idle...'}</p>
        </div>
      )}
    </>
  );
}
